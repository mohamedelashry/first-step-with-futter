# sample_flutter_app

A sample Flutter application.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

## Flutter codelab
- part 1 : https://flutter.io/get-started/codelab/
- part 2 : https://codelabs.developers.google.com/codelabs/first-flutter-app-pt2/#2
# codelabs-flutter-projects First Flutter App
